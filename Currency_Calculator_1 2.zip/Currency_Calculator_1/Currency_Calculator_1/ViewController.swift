//
//  ViewController.swift
//  Currency_Calculator_1
//
//  Created by Emily Denham on 2/16/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var EnterUSD: UITextField!
    
    @IBOutlet weak var Switch1: UISwitch!
    @IBOutlet weak var Switch2: UISwitch!
    @IBOutlet weak var Switch3: UISwitch!
    @IBOutlet weak var Switch4: UISwitch!
    @IBOutlet weak var errorLabel: UILabel!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        errorLabel.isHidden = true
    }

    @IBAction func convertTapped(_ sender: UIButton) {
        guard let amountText = EnterUSD.text, let amount = Int(amountText) else {
            errorLabel.text = "Invalid input. Please enter an integer."
            errorLabel.isHidden = false
            return
        }
        performSegue(withIdentifier: "showCurrencyConversion", sender: amount)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showCurrencyConversion",
           let destinationVC = segue.destination as? NavigationViewController,
           let amount = sender as? Int {
            destinationVC.amountUSD = amount
            destinationVC.currencySwitchStates = [Switch1.isOn, Switch2.isOn, Switch3.isOn, Switch4.isOn]
            print("Passing switch states: \([Switch1.isOn, Switch2.isOn, Switch3.isOn, Switch4.isOn])")
        }
    }
}
