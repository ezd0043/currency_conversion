//
//  NavigationViewController.swift
//  Currency_Calculator_1
//
//  Created by Emily Denham on 2/18/24.
//

import UIKit

class NavigationViewController: UIViewController {
    
    @IBOutlet weak var currency1Label: UILabel!
    @IBOutlet weak var currency2Label: UILabel!
    @IBOutlet weak var currency3Label: UILabel!
    @IBOutlet weak var currency4Label: UILabel!
    
    var amountUSD: Int?
        var currencySwitchStates: [Bool]?
        
        let conversionRates = [1.1, 0.9, 74.23, 109.17] // Rates for EUR, GBP, INR, JPY
        
        override func viewDidLoad() {
            super.viewDidLoad()
                print("Received switch states: \(String(describing: currencySwitchStates))")
                updateCurrencyLabels()
        }
    
    func updateCurrencyLabels() {
           guard let amount = amountUSD, let switchStates = currencySwitchStates else { return }
           
           let currencyNames = ["EUR", "GBP", "INR", "JPY"]
           let labels = [currency1Label, currency2Label, currency3Label, currency4Label]
           
           for (index, label) in labels.enumerated() {
               if switchStates[index] {
                   let conversionRate = conversionRates[index]
                   let convertedAmount = Double(amount) * conversionRate
                   label?.text = "\(currencyNames[index]): \(String(format: "%.2f", convertedAmount))"
                   label?.isHidden = false
               } else {
                   label?.isHidden = true
               }
           }
       }
}
